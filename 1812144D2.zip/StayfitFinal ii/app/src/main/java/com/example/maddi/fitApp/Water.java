package com.example.maddi.fitApp;

public class Water {
    public int totalwater;

    public Water() {
        // Default constructor required for calls to DataSnapshot.getValue(Steps.class)
    }

    public Water(int totalwater) {
        this.totalwater = totalwater;
    }
}
